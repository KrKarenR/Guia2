/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.parqueaderomvc;

/**
 *
 * @author krkar
 */
public class ParqueaderoMVC {

    public static void main(String[] args) {
        System.out.println("Hello World!");
    }
}
