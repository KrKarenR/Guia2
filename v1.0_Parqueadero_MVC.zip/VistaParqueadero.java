import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class VistaParqueadero extends JFrame {
    private JTextField txtPlacaIngreso, txtMarcaIngreso, txtModeloIngreso;
    private JComboBox<String> comboTipo;
    private JTextField txtPlacaSalida;
    private JButton btnIngreso, btnSalida;
    private JTable tablaVehiculos;
    private ControladorParqueadero controlador;

    public VistaParqueadero(ControladorParqueadero controlador) {
        this.controlador = controlador;
        setTitle("Parqueadero MVC");
        setSize(800, 400);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLayout(new BorderLayout());

        // Panel ingreso
        JPanel panelIngreso = new JPanel(new GridLayout(4, 2));
        panelIngreso.setBorder(BorderFactory.createTitledBorder("Ingreso de Vehículos"));
        txtPlacaIngreso = new JTextField();
        txtMarcaIngreso = new JTextField();
        txtModeloIngreso = new JTextField();
        comboTipo = new JComboBox<>(new String[]{"Carro", "Moto"});
        btnIngreso = new JButton("Ingresar");

        panelIngreso.add(new JLabel("Placa:"));
        panelIngreso.add(txtPlacaIngreso);
        panelIngreso.add(new JLabel("Marca:"));
        panelIngreso.add(txtMarcaIngreso);
        panelIngreso.add(new JLabel("Modelo:"));
        panelIngreso.add(txtModeloIngreso);
        panelIngreso.add(new JLabel("Tipo:"));
        panelIngreso.add(comboTipo);

        // Panel salida
        JPanel panelSalida = new JPanel(new GridLayout(2, 2));
        panelSalida.setBorder(BorderFactory.createTitledBorder("Salida de Vehículos"));
        txtPlacaSalida = new JTextField();
        btnSalida = new JButton("Retirar");
        panelSalida.add(new JLabel("Placa:"));
        panelSalida.add(txtPlacaSalida);
        panelSalida.add(new JLabel(""));
        panelSalida.add(btnSalida);

        // Tabla
        tablaVehiculos = new JTable(new javax.swing.table.DefaultTableModel(
            new Object[][]{},
            new String[]{"Placa", "Marca", "Modelo", "Tipo"}
        ));
        JScrollPane scrollTabla = new JScrollPane(tablaVehiculos);

        // Agregar componentes al frame
        JPanel panelTop = new JPanel(new GridLayout(1, 2));
        panelTop.add(panelIngreso);
        panelTop.add(panelSalida);
        add(panelTop, BorderLayout.NORTH);
        add(scrollTabla, BorderLayout.CENTER);
        add(btnIngreso, BorderLayout.SOUTH);

        // Eventos
        btnIngreso.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                controlador.ingresarVehiculo(
                    txtPlacaIngreso.getText(),
                    txtMarcaIngreso.getText(),
                    txtModeloIngreso.getText(),
                    comboTipo.getSelectedItem().toString()
                );
            }
        });

        btnSalida.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                controlador.retirarVehiculo(txtPlacaSalida.getText());
            }
        });
    }

    public JTable getTablaVehiculos() {
        return tablaVehiculos;
    }
}
