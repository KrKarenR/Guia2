import java.util.ArrayList;
import java.util.List;

public class ModeloParqueadero {
    private List<Vehiculo> vehiculos = new ArrayList<>();

    public void ingresarVehiculo(Vehiculo vehiculo) {
        vehiculos.add(vehiculo);
    }

    public boolean retirarVehiculo(String placa) {
        return vehiculos.removeIf(v -> v.getPlaca().equalsIgnoreCase(placa));
    }

    public List<Vehiculo> obtenerVehiculos() {
        return new ArrayList<>(vehiculos);
    }
}
