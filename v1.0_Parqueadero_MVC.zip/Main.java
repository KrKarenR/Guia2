public class Main {
    public static void main(String[] args) {
        ModeloParqueadero modelo = new ModeloParqueadero();
        new ControladorParqueadero(modelo);
    }
}
