import java.util.List;
import javax.swing.table.DefaultTableModel;

public class ControladorParqueadero {
    private ModeloParqueadero modelo;
    private VistaParqueadero vista;

    public ControladorParqueadero(ModeloParqueadero modelo) {
        this.modelo = modelo;
        this.vista = new VistaParqueadero(this);
        this.vista.setVisible(true);
    }

    public void ingresarVehiculo(String placa, String marca, String modelo, String tipo) {
        Vehiculo vehiculo = new Vehiculo(placa, marca, modelo, tipo);
        this.modelo.ingresarVehiculo(vehiculo);
        actualizarTabla();
    }

    public void retirarVehiculo(String placa) {
        this.modelo.retirarVehiculo(placa);
        actualizarTabla();
    }

    public void actualizarTabla() {
        List<Vehiculo> vehiculos = modelo.obtenerVehiculos();
        DefaultTableModel tabla = (DefaultTableModel) vista.getTablaVehiculos().getModel();
        tabla.setRowCount(0);
        for (Vehiculo v : vehiculos) {
            tabla.addRow(new Object[]{v.getPlaca(), v.getMarca(), v.getModelo(), v.getTipo()});
        }
    }
}
